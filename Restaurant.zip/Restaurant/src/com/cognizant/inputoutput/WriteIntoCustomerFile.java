package com.cognizant.inputoutput;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cognizant.inputoutput.ReadCsv;
import com.cognizant.entity.*;

public class WriteIntoCustomerFile{
	int count = 0;
		public int getCount(){
			return count;
		}
	public List<SummaryReport> writeIntoCustomer(List<OrderDetails> orderDetail){
		DecimalFormat df = new DecimalFormat("0.00");
		ArrayList<SummaryReport> summaryDetail = new ArrayList<SummaryReport>();
		try{
			for(OrderDetails orderFile : orderDetail){
				SummaryReport summaryFile = new SummaryReport();
				String fileName = "D:\\"+orderFile.getCustomerId();
				File customer_File = new File(fileName);
				customer_File.createNewFile();
				BufferedWriter bw = new BufferedWriter(new FileWriter(fileName,true));
				double totalAmount = 0;
				
				DataInputStream input = new DataInputStream(new FileInputStream(fileName));
				
				boolean flag = true;
				
				if(customer_File.exists() && input.available() ==0){
					for(OrderDetails ofile : orderDetail){
						if (input.available() == 0 && flag){
							flag = false;
							bw.append("Generated Bill for Customer C0023");
							bw.newLine();
							bw.append(String.format("%-27s %-10s","","Happy Restaurant"));
							bw.newLine();
							bw.append(String.format("%-30s %-10s","","08/02/2019"));
							bw.newLine();
							bw.append("=======================================================================");
							bw.newLine();
							bw.append(String.format("%-25s %-12s %-25s %-15s","Item","Qty","Unit Price", "Total"));
							bw.newLine();
							bw.append("=======================================================================");
							//System.out.println("append");
						}
						
						if(fileName.equals("D:\\"+ofile.getCustomerId())){
							double itemTotal =0;
							itemTotal = Integer.parseInt(ofile.getQuantity())*Integer.parseInt(ofile.getUnitPrice());
							bw.newLine();
							bw.append(String.format("%-25s %-12s %-25s %-15s",ofile.getMenuItem(),ofile.getQuantity(),df.format(Double.parseDouble(ofile.getUnitPrice())),df.format(itemTotal)));
							totalAmount = totalAmount + itemTotal;
							//System.out.println("append1");
						}
					}
	
					if(!flag){
						bw.newLine();
						bw.append("=======================================================================");
						bw.newLine();
						bw.append(String.format("%-25s %-12s %-25s %-15s","Grand Total","","", df.format(totalAmount)));
						bw.newLine();
						bw.append("=======================================================================");
						//System.out.println("append2");
						count++;
						summaryFile.setCustomerId(orderFile.getCustomerId());
						summaryFile.setTotalAmount(totalAmount);
						summaryFile.setWaiterId(orderFile.getWaiterId());
						summaryDetail.add(summaryFile);
					}
				}
				bw.close();
			}
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			System.out.println("Read file successfully");
			return summaryDetail;
		}
	}
}