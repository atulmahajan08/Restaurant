package com.cognizant.inputoutput;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import com.cognizant.entity.OrderDetails;

public class ReadCsv{
	String inputFile = "D://Order_File.csv";
	public ArrayList<OrderDetails> readFile() {
		ArrayList<OrderDetails> orderDetailList = new ArrayList<OrderDetails>();
		
		try {
			Scanner scanner = new Scanner(new File(inputFile));
			Scanner dataScanner = null;
			int index = 0;
			while (scanner.hasNextLine()) {
				dataScanner = new Scanner(scanner.nextLine());
				dataScanner.useDelimiter(",");
				OrderDetails orderDetails = new OrderDetails();
				//String fileName = null;
				
				while(dataScanner.hasNext()){
					String data = dataScanner.next();
					if (index == 0){
						orderDetails.setCustomerId(data);
						//fileName = data;
					}
					else if (index == 1){
						orderDetails.setTableNumber(data);
					}
					else if (index == 2){
						orderDetails.setWaiterId(data);
					}
					else if (index == 3){
						orderDetails.setMenuItem(data);
					}
					else if (index == 4){
						orderDetails.setQuantity(data);
					}
					else if(index == 5){
						orderDetails.setUnitPrice(data);
					}
					index++;
				}
				//System.out.println(orderDetails.getCustomerId());
				index = 0;
				orderDetailList.add(orderDetails);
			}
			//System.out.println("File read");
		}catch(Exception e){
		e.printStackTrace();
		}
		return(orderDetailList);	
	}
}