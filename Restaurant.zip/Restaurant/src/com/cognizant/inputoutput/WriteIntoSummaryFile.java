package com.cognizant.inputoutput;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cognizant.inputoutput.WriteIntoCustomerFile;
import com.cognizant.entity.*;

public class WriteIntoSummaryFile{
	public void writeIntoSummaryReport(List<SummaryReport> summaryDetail, int count){
		DecimalFormat df = new DecimalFormat("0.00");
		int check =0;
		double grandTotal = 0;
		try{
			for(SummaryReport summary : summaryDetail){
				String fileName = "D:\\Summary";
				File summary_File = new File(fileName);
				summary_File.createNewFile();
				BufferedWriter bwr = new BufferedWriter(new FileWriter(fileName,true));
				DataInputStream dataInput = new DataInputStream(new FileInputStream(fileName));
					if(summary_File.exists() && dataInput.available()==0){
						bwr.append("Summary report");
						bwr.newLine();
						bwr.append(String.format("%-20s %-10s","","Happy Restaurant"));
						bwr.newLine();
						bwr.append(String.format("%-23s %-10s","","08/02/2109"));
						bwr.newLine();
						bwr.append("Waiter: "+summary.getWaiterId());
						bwr.newLine();
						bwr.append("==========================================");
						bwr.newLine();
						bwr.append(String.format("%-30s %-12s", "Customer","Bill Amount"));
						bwr.newLine();
						bwr.append("==========================================");
					}
						grandTotal = grandTotal + summary.getTotalAmount();
						bwr.newLine();
						bwr.append(String.format("%-30s %-12s",summary.getCustomerId(),df.format(summary.getTotalAmount())));
						check++;
					if(check==count){
						bwr.newLine();
						bwr.append("==========================================");
						bwr.newLine();
						bwr.append(String.format("%-30s %-12s", "Grand Total",df.format(grandTotal)));
						bwr.newLine();
						bwr.append("==========================================");
					}
					bwr.close();
				}			
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			System.out.println("Files Created");
		}
	}
}