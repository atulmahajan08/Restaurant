package com.cognizant.entity;

public class SummaryReport{
	private String customerId;
	private String waiterId;
	private double totalAmount;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getWaiterId() {
		return waiterId;
	}
	public void setWaiterId(String waiterId) {
		this.waiterId = waiterId;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

}