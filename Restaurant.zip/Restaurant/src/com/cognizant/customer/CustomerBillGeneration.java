package com.cognizant.customer;

import java.util.List;
import java.util.ArrayList;
import com.cognizant.entity.OrderDetails;
import com.cognizant.entity.SummaryReport;
import com.cognizant.inputoutput.ReadCsv;
import com.cognizant.inputoutput.WriteIntoCustomerFile;
import com.cognizant.inputoutput.WriteIntoSummaryFile;

public class CustomerBillGeneration{
	public static void main(String args[]){
	int count = 0;
	ReadCsv read = new ReadCsv();
	List<OrderDetails> inputList = new ArrayList<>();
	inputList = read.readFile();
	WriteIntoCustomerFile write = new WriteIntoCustomerFile();	
	List<SummaryReport> summaryInput = new ArrayList<>();
	summaryInput = write.writeIntoCustomer(inputList);
	for(SummaryReport sr : summaryInput){
	System.out.println(sr.getTotalAmount());
	}
	WriteIntoSummaryFile writeSummary = new WriteIntoSummaryFile();
	count = write.getCount();
	writeSummary.writeIntoSummaryReport(summaryInput, count);
	}
}